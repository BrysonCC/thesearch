// (function(module) {
//   var dns = require('dns');

//   'use strict';

//   module.exports = function getIP(domain) {



//   }
// })(module);
